# BooksWorld
    • This is a web development based project provides summaries of some well known books of all categories like Fiction,Non-Fiction,Stories,Biographies,Autobiographies. History,Comics,Science and Philosophy.<br>
    • This website also allow users to recommend books which are known to them.<br>
    • Here our website provided e-commerce website links where users can buy books that they like by reading the provided summaries.<br>
